INSERT INTO Offer_Code(buy_Count,get_Count) VALUES (1, 0);
INSERT INTO Offer_Code(buy_Count,get_Count) VALUES (2, 1);
INSERT INTO Offer_Code(buy_Count,get_Count) VALUES (2, 50);
INSERT INTO Product(name,price) VALUES ('Dove Soap', 39.99);