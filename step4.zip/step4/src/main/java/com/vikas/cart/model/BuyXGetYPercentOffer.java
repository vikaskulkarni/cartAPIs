package com.vikas.cart.model;

public class BuyXGetYPercentOffer extends OfferCode {
    @Override
    public Float getDiscount(int quantity, Float price) {
        return null;
    }
}
